package com.example.hoteligoadmin;

public class Detail {
    public String title, address, description, price;

    public Detail () {

    }

    public Detail(String title, String address, String description, String price) {
        this.title = title;
        this.address = address;
        this.description = description;
        this.price = price;

    }
}
